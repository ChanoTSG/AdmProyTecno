package com.example.chano.epdeportivo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.chano.epdeportivo.model.PreparacionFisica;

import java.util.ArrayList;

public class PreparacionFisicaAdapter extends BaseAdapter {

    private LayoutInflater layoutInflater;
    private Context c;
    private ArrayList<PreparacionFisica> lista;

    private TextView tv_detalle,tv_titulo;
    private ImageView iv_preparacion;

    public PreparacionFisicaAdapter(Context c, ArrayList<PreparacionFisica> lista){
        this.c=c;
        this.layoutInflater=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.lista=lista;

    }

    @Override
    public int getCount() {
        return lista.size();
    }

    @Override
    public Object getItem(int position) {
        return lista.get(position);
    }

    @Override
    public long getItemId(int position) {
        return lista.indexOf(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view  = convertView;
        if(convertView==null){
            view = layoutInflater.inflate(R.layout.item_preparacion_adapter,null,true);

        }
        tv_detalle=(TextView)view.findViewById(R.id.tv_detalle);
        tv_titulo=(TextView)view.findViewById(R.id.tv_titulo);
        iv_preparacion=(ImageView)view.findViewById(R.id.iv_preparacion);

        PreparacionFisica preparacion = lista.get(position);

        tv_detalle.setText(preparacion.getDescripcion());
        tv_titulo.setText(preparacion.getTitulo());
        iv_preparacion.setImageResource(preparacion.getImage());

        return view;
    }


}
