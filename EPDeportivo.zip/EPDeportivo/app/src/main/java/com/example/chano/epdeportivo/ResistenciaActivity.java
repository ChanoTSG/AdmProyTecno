package com.example.chano.epdeportivo;

import android.app.DatePickerDialog;
import java.util.Calendar;

import android.database.SQLException;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chano.epdeportivo.db.ResistenciaDataSource;
import com.example.chano.epdeportivo.db.UserDataSource;
import com.example.chano.epdeportivo.model.Resistencia;
import com.example.chano.epdeportivo.model.User;

import java.util.ArrayList;
import java.util.List;

public class ResistenciaActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText et_km;
    private TextView tv_fecha,cronometro,et_nombre_deportista;
    private Button btn_start,btn_pause,btn_reset,btn_fecha,btn_agregar;
    private boolean running;

    private ArrayList<Resistencia> lista;
    private ArrayAdapter<Resistencia> adapter;
    private ListView lv_carreras;


    long startTime=0L,timeInMilliSeconds=0L,timeSwapBuff=0L,updateTime=0L;
    Handler customHandler=new Handler();
    Runnable updateTimerThread = new Runnable() {
        @Override
        public void run() {
            timeInMilliSeconds = SystemClock.uptimeMillis()-startTime;
            updateTime=timeSwapBuff+timeInMilliSeconds;
            int secs = (int)updateTime/1000;
            int min = secs/60;
            secs %=60;
            int milliseconds = (int) (updateTime%1000);
            cronometro.setText(""+String.format("%02d",min)+":"+String.format("%02d",secs)+":"+String.format("%03d",milliseconds));
            customHandler.postDelayed(this,0);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resistencia);

        btn_pause=(Button)findViewById(R.id.btn_pause);
        btn_reset=(Button)findViewById(R.id.btn_reset);
        btn_start=(Button)findViewById(R.id.btn_start);

        btn_fecha=(Button)findViewById(R.id.btn_fecha);
        btn_agregar=(Button)findViewById(R.id.btn_agregar);

        et_km=(EditText)findViewById(R.id.et_km);
        tv_fecha=(TextView)findViewById(R.id.tv_fecha);
        cronometro = (TextView)findViewById(R.id.cronometro);
        et_nombre_deportista = (TextView)findViewById(R.id.et_nombre_deportista);


        btn_pause.setOnClickListener(this);
        btn_reset.setOnClickListener(this);
        btn_start.setOnClickListener(this);
        btn_agregar.setOnClickListener(this);
        btn_fecha.setOnClickListener(this);

        Calendar calendar = Calendar.getInstance();
        String mes = ((Calendar.MONTH+1)<10)?String.valueOf("0"+(Calendar.MONTH+1)):String.valueOf(Calendar.MONTH + 1);
        String fecha = calendar.get(Calendar.YEAR)+"-"+mes+"-"+calendar.get(Calendar.DAY_OF_MONTH);
        tv_fecha.setText(fecha);

        lv_carreras = (ListView)findViewById(R.id.lv_carreras);

        User u =loadUser();
        if(u!=null){
            lista=listarResistencia(u.getUser_id());
            if(lista.size()>0){
                adapter =new ArrayAdapter<Resistencia>(ResistenciaActivity.this,android.R.layout.simple_list_item_1,lista);
                lv_carreras.setAdapter(adapter);
            }else{
                lista=new ArrayList<>();
            }

        }

    }

    private ArrayList<Resistencia> listarResistencia(int user_id){
        ArrayList<Resistencia> lista = null;
        ResistenciaDataSource ds = new ResistenciaDataSource(ResistenciaActivity.this);
        try{
            ds.open();
            lista=ds.getListadoResistencia(user_id);
        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return lista;
    }

    private void saveResistencia(Resistencia r){
        ResistenciaDataSource ds = new ResistenciaDataSource(ResistenciaActivity.this);
        try{
            ds.open();
            ds.insert(r);
        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private User loadUser(){
        User u=null;
        UserDataSource ds=new UserDataSource(ResistenciaActivity.this);
        try{
            ds.open();
            u=ds.loadUser(1);

        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(ResistenciaActivity.this,"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return u;
    }

    long pauseOffset = 0;

    public void onClick(View v) {
        if (v == btn_start) {
            start();
        }else if(v == btn_reset){
            reset();
        }else if(v == btn_pause){
            pause();
        }else if(v == btn_fecha){
            setFecha();
        }else if(v == btn_agregar){
            agregarLista();
        }
    }

    private void agregarLista(){
        if(validation()){
            Resistencia r = new Resistencia();
            r.setDistancia(Float.parseFloat(et_km.getText().toString()));
            r.setTiempo(cronometro.getText().toString());
            r.setFecha(tv_fecha.getText().toString());
            r.setId_user(loadUser().getUser_id());
            r.setNombreCompletoDeportista(et_nombre_deportista.getText().toString());
            lista.add(r);
            saveResistencia(r);
            if(lv_carreras.getCount()==0){
                adapter =new ArrayAdapter<Resistencia>(ResistenciaActivity.this,android.R.layout.simple_list_item_1,lista);
            }else{

                adapter.notifyDataSetChanged();
                lista=listarResistencia(loadUser().getUser_id());
                adapter =new ArrayAdapter<Resistencia>(ResistenciaActivity.this,android.R.layout.simple_list_item_1,lista);
            }
            lv_carreras.setAdapter(adapter);

        }
    }

    private boolean validation(){
        return (tv_fecha.getText().length()>0&&
                et_km.getText().length()>0&&
                et_nombre_deportista.getText().length()>0);
    }

    private void setFecha(){
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String mes = ((month+1)<10)?String.valueOf("0"+(month+1)):String.valueOf(month + 1);
                tv_fecha.setText(year+"-"+mes+"-"+dayOfMonth);
            }
        },calendar.DAY_OF_MONTH,calendar.MONTH,calendar.YEAR);
        dialog.show();
    }

    private void start(){
        startTime =  SystemClock.uptimeMillis();

        customHandler.postDelayed(updateTimerThread,0);
    }

    private void reset(){

    }

    private void pause(){
        timeSwapBuff+=timeInMilliSeconds;
        customHandler.removeCallbacks(updateTimerThread);
    }
}