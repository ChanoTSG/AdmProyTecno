package com.example.chano.epdeportivo;


import android.content.Intent;
import android.database.SQLException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chano.epdeportivo.db.UserDataSource;
import com.example.chano.epdeportivo.model.User;

public class LoginActivity extends AppCompatActivity {
    private CardView cv_login;
    private TextView tv_registrarse;
    private EditText et_password, et_user;

    public static User u;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        tv_registrarse=(TextView)findViewById(R.id.tv_registrarse);
        cv_login=(CardView)findViewById(R.id.cv_login);

        et_password=(EditText)findViewById(R.id.et_password);
        et_user=(EditText)findViewById(R.id.et_user);

        cv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                    if(userSession(et_user.getText().toString(),et_password.getText().toString())){
                       startActivity(new Intent(LoginActivity.this,MainActivity.class));
                    }
                }else{
                    Toast.makeText(getApplicationContext(),"Llene los campos ",Toast.LENGTH_LONG).show();
                }
            }
        });

        tv_registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,RegistrarActivity.class));
            }
        });
    }

    private boolean validate(){
        return (et_password.getText().length()>0||et_user.getText().length()>0);
    }


    private boolean userSession(String email, String password){
        UserDataSource ds=new UserDataSource(getApplicationContext());
        try{
            ds.open();
            u=ds.loginUser(email.toLowerCase());
            if(u!=null){
                if(!password.equals(u.getPassword())){
                    Toast.makeText(getApplicationContext(),"Password incorrecto: ",Toast.LENGTH_LONG).show();
                    return false;
                }else{
                    ds.disableUsers(u.getUser_id());
                }
            }else{
                Toast.makeText(getApplicationContext(),"Usuario no existe: ",Toast.LENGTH_LONG).show();
                return false;
            }
        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }


        return true;
    }
}
