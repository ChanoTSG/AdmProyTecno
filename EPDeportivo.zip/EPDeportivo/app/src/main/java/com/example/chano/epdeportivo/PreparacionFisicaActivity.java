package com.example.chano.epdeportivo;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;


import com.example.chano.epdeportivo.model.PreparacionFisica;

import java.util.ArrayList;

public class PreparacionFisicaActivity extends Activity {
    ListView lv_preparacion;
    ArrayList<PreparacionFisica> lista;
    PreparacionFisicaAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preparacion_fisica);
        lv_preparacion=(ListView)findViewById(R.id.lv_preparacion);

        lista = setListado();

        adapter= new PreparacionFisicaAdapter(PreparacionFisicaActivity.this, lista);

        lv_preparacion.setAdapter(adapter);
        lv_preparacion.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DialogDetalle dialog = new DialogDetalle(PreparacionFisicaActivity.this,lista.get(position));
                dialog.show();
            }
          }
        );

    }


    private ArrayList<PreparacionFisica> setListado(){
        ArrayList<PreparacionFisica> l = new ArrayList<>();
        PreparacionFisica p1 = new PreparacionFisica();
        p1.setTitulo(" Patada inestable");
        p1.setDescripcion("Para mejorar el sistema propioceptivo, es aconsejable la utilización de superficies inestables como el bosu en combinación con gestos específicos como golpeos y patadas.");
        p1.setImage(R.drawable.primero);
        l.add(p1);

        PreparacionFisica pa1 = new PreparacionFisica();
        pa1.setTitulo(" Multisaltos");
        pa1.setDescripcion("Con un banco o un step realiza saltos a los lados superando la altura.");
        pa1.setImage(R.drawable.a1);
        l.add(pa1);

        PreparacionFisica pa2 = new PreparacionFisica();
        pa2.setTitulo(" Multisaltos");
        pa2.setDescripcion("Realiza saltos verticales sobre superficies inestables como el bosu, si deseas algo más de intensidad, sujeta un disco con tus brazos, obligarás a un mayor trabajo de ajuste rápido a tus piernas.");
        pa2.setImage(R.drawable.a2);
        l.add(pa2);

        PreparacionFisica p2 = new PreparacionFisica();
        p2.setTitulo(" Cambios de dirección");
        p2.setDescripcion(" Es necesario trabajar la resistencia con desplazamientos laterales para implicar a los músculos que intervienen en las frenadas y desplazamientos laterales.");
        p2.setImage(R.drawable.segundo);
        l.add(p2);

        PreparacionFisica p3 = new PreparacionFisica();
        p3.setTitulo(" Carrera resistida");
        p3.setDescripcion(" Para mejorar la velocidad, realiza salidas rápidas con un tensor sujeto a tu cintura que te ofrezca resistencia.");
        p3.setImage(R.drawable.tercero);
        l.add(p3);

        PreparacionFisica pb1 = new PreparacionFisica();
        pb1.setTitulo(" Refuerza la cinturaa");
        pb1.setDescripcion(" Es necesario realizar ejercicios de core con posiciones de fondo cambiando apoyos e inclinaciones laterales para reforzar toda la musculatura del tronco.");
        pb1.setImage(R.drawable.b1);
        l.add(pb1);

        PreparacionFisica pb2 = new PreparacionFisica();
        pb2.setTitulo(" Refuerza la cintura");
        pb2.setDescripcion(" Es necesario realizar ejercicios de core con posiciones de fondo cambiando apoyos e inclinaciones laterales para reforzar toda la musculatura del tronco.");
        pb2.setImage(R.drawable.b2);
        l.add(pb2);

        PreparacionFisica p4 = new PreparacionFisica();
        p4.setTitulo(" Estira en dinámico");
        p4.setDescripcion(" Es necesario estirar bien los aductores, pero mejor con estiramientos dinámicos. Desplaza tu cuerpo lateralmente separando las piernas para lograr el estiramiento de la musculatura interna de la pierna.");
        p4.setImage(R.drawable.cuarto);
        l.add(p4);

        return l;
    }
}
