package com.example.chano.epdeportivo.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.chano.epdeportivo.model.Resistencia;
import com.example.chano.epdeportivo.model.User;

import java.util.ArrayList;
import java.util.List;

public class ResistenciaDataSource {


    public String [] allColumns = {
            DataBaseHelper.ID_USER_RESISENCIA,
            DataBaseHelper.ID_RESISTENCIA,
            DataBaseHelper.FECHA,
            DataBaseHelper.TIEMPO,
            DataBaseHelper.DISTANCIA,
            DataBaseHelper.NOMBREDEPORTISTA,
    };

    private SQLiteDatabase database;
    private DataBaseHelper dbHelper;

    public ResistenciaDataSource(Context c){
        dbHelper=new DataBaseHelper(c);
    }

    public void open() throws SQLException {
        database = dbHelper.getReadableDatabase();
    }

    public void close(){
        dbHelper.close();
    }

    private ContentValues resistenciaValues(Resistencia r){
        ContentValues v = new ContentValues();
        if( r.getId()>0 )
            v.put(DataBaseHelper.ID_RESISTENCIA,r.getId());
        v.put(DataBaseHelper.ID_USER_RESISENCIA,r.getId_user());
        v.put(DataBaseHelper.FECHA,r.getFecha());
        v.put(DataBaseHelper.TIEMPO,r.getTiempo());
        v.put(DataBaseHelper.DISTANCIA,r.getDistancia());
        v.put(DataBaseHelper.NOMBREDEPORTISTA,r.getNombreCompletoDeportista());
        return v;
    }


    public long insert(Resistencia r){
        ContentValues v = resistenciaValues(r);
        long resp = database.insert(DataBaseHelper.TBL_RESISTENCIA,null,v);
        return resp;
    }

    public long actualizar(Resistencia r){
        ContentValues v = resistenciaValues(r);
        long resp = database.update(DataBaseHelper.TBL_RESISTENCIA,v,DataBaseHelper.ID_RESISTENCIA+"="+r.getId(),null);
        return resp;
    }


    public ArrayList<Resistencia> getListadoResistencia(int id_usuario){
        ArrayList<Resistencia> lista = new ArrayList<Resistencia>();
        Cursor c= null;
        try{
            c=database.query(DataBaseHelper.TBL_RESISTENCIA,allColumns,DataBaseHelper.ID_USER_RESISENCIA+"="+id_usuario,null,null,null,DataBaseHelper.ID_RESISTENCIA+" DESC");
            Resistencia r=null;
            if(c.getCount()>0){
               c.moveToFirst();
               while(!c.isAfterLast()){
                r = new Resistencia();
                r.setId(c.getInt(c.getColumnIndex(DataBaseHelper.ID_RESISTENCIA)));
                r.setId_user(c.getInt(c.getColumnIndex(DataBaseHelper.ID_USER_RESISENCIA)));
                r.setFecha(c.getString(c.getColumnIndex(DataBaseHelper.FECHA)));
                r.setTiempo(c.getString(c.getColumnIndex(DataBaseHelper.TIEMPO)));
                r.setDistancia(c.getFloat(c.getColumnIndex(DataBaseHelper.DISTANCIA)));
                r.setNombreCompletoDeportista(c.getString(c.getColumnIndex(DataBaseHelper.NOMBREDEPORTISTA)));
                lista.add(r);
                c.moveToNext();
               }
            }
        }finally{
            c.close();
        }
        return lista;
    }

}
