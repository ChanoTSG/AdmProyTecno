package com.example.chano.epdeportivo;

import android.database.SQLException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.chano.epdeportivo.db.IndiceMasaCorporalDataSouce;
import com.example.chano.epdeportivo.db.ResistenciaDataSource;
import com.example.chano.epdeportivo.db.UserDataSource;
import com.example.chano.epdeportivo.model.IndiceMasaCorporal;
import com.example.chano.epdeportivo.model.Resistencia;
import com.example.chano.epdeportivo.model.User;

import java.util.ArrayList;

public class HistorialIMCActivity extends AppCompatActivity {


    ListView lv_historial;
    ArrayList<IndiceMasaCorporal> lista_imc;
    ArrayAdapter<IndiceMasaCorporal> adapter;
    Button btn_buscar;
    EditText et_nombre;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial_imc);

        lv_historial = (ListView)findViewById(R.id.lv_historial);
        btn_buscar = (Button)findViewById(R.id.btn_buscar);
        et_nombre = (EditText)findViewById(R.id.et_nombre);

        lista_imc = getHistorial(loadUser().getUser_id(), et_nombre.getText().toString());
        adapter = new ArrayAdapter<IndiceMasaCorporal>(HistorialIMCActivity.this,android.R.layout.simple_list_item_1,lista_imc);
        lv_historial.setAdapter(adapter);

        btn_buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lista_imc = getHistorial(loadUser().getUser_id(), et_nombre.getText().toString());
                adapter.notifyDataSetChanged();
                adapter = new ArrayAdapter<IndiceMasaCorporal>(HistorialIMCActivity.this,android.R.layout.simple_list_item_1,lista_imc);
                lv_historial.setAdapter(adapter);
            }
        });
    }


    private User loadUser(){
        User u=null;
        UserDataSource ds=new UserDataSource(HistorialIMCActivity.this);
        try{
            ds.open();
            u=ds.loadUser(1);

        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(HistorialIMCActivity.this,"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return u;
    }


    private ArrayList<IndiceMasaCorporal> getHistorial(int user_id,String deportista){
        ArrayList<IndiceMasaCorporal> lista = null;
        IndiceMasaCorporalDataSouce ds = new IndiceMasaCorporalDataSouce(HistorialIMCActivity.this);
        try{
            ds.open();
            lista=ds.getHistorialIMC(user_id,deportista);
        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return lista;
    }

}
