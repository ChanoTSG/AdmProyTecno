package com.example.chano.epdeportivo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lv_opciones;
    private ArrayList<Option> lista;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista = new ArrayList<>();
        lista.add(getOption("Medir Resistencia",R.drawable.ic_recent_actors_black_24dp,R.drawable.circlebackgoundpurple));
        lista.add(getOption("Preparacion Fisica",R.drawable.ic_fitness_center_black_24dp,R.drawable.circlebackgroundgreen));
        lista.add(getOption("Rango Saluble",R.drawable.ic_thumb_up_black_24dp,R.drawable.circlebackgroundpink));
        lista.add(getOption("Historico IMC",R.drawable.ic_assessment_black_24dp,R.drawable.circlebackgroundyello));
        lista.add(getOption("Salir",R.drawable.ic_transfer_within_a_station_black_24dp,R.drawable.circlebackgroundlightgreen));
        ItemOptionAdapter adaptador = new ItemOptionAdapter(this,lista);
        lv_opciones= (ListView)findViewById(R.id.lv_opciones);
        lv_opciones.setAdapter(adaptador);
        lv_opciones.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                boolean salida = false;
                if(position==0){
                    startActivity(new Intent(MainActivity.this,ResistenciaActivity.class));
                }else if(position==1){
                    startActivity(new Intent(MainActivity.this,PreparacionFisicaActivity.class));
                }else if(position==2){
                    startActivity(new Intent(MainActivity.this,IndiceMasaCorporalActivity.class));
                }else if(position==3){
                    startActivity(new Intent(MainActivity.this,HistorialIMCActivity.class));
                }else if(position==4){
                    startActivity(new Intent(MainActivity.this,LoginActivity.class));
                    salida=true;
                    finish();
                }

            }
        });




    }


    private Option getOption(String titulo, int img, int fondo){
        Option op = new Option();
        op.setOp_name(titulo);
        op.setImage(img);
        op.setFondo(fondo);
        return op;
    }
}
