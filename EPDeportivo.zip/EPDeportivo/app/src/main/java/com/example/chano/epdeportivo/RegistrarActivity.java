package com.example.chano.epdeportivo;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.SQLException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import android.app.AlertDialog;
import android.content.DialogInterface;

import com.example.chano.epdeportivo.db.UserDataSource;
import com.example.chano.epdeportivo.model.User;

public class RegistrarActivity extends AppCompatActivity {

    CardView cv_volver, cv_guardar,cv_borrar;
    EditText et_nombre,et_email,et_password,et_conf_password,et_direccion;


    private UserDataSource ds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        cv_guardar=(CardView)findViewById(R.id.cv_guardar);
        cv_volver=(CardView)findViewById(R.id.cv_volver);
        cv_borrar=(CardView)findViewById(R.id.cv_borrar);

        et_nombre=(EditText)findViewById(R.id.et_nombre);
        et_email=(EditText)findViewById(R.id.et_email);
        et_password=(EditText)findViewById(R.id.et_password);
        et_conf_password=(EditText)findViewById(R.id.et_conf_password);
        et_direccion=(EditText)findViewById(R.id.et_direccion);

        cv_guardar.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if(errCode()==2){
                    Toast.makeText(RegistrarActivity.this,"Los password son distintos",Toast.LENGTH_LONG).show();
                }else if(errCode()==0){
                    Toast.makeText(RegistrarActivity.this,"Llene Todos los campos",Toast.LENGTH_LONG).show();
                }else{
                    User user = new User();
                    user.setFullname(et_nombre.getText().toString());
                    user.setEmail(et_email.getText().toString());
                    user.setPassword(et_password.getText().toString());
                    user.setDireccion(et_direccion.getText().toString());
                    user.setKeepSession(1);
                    ds = new UserDataSource(RegistrarActivity.this);

                    try{
                        ds.open();
                        if(!ds.validateEmail(et_email.getText().toString())){
                            if(ds.userExist(et_nombre.getText().toString(),et_email.getText().toString(),et_password.getText().toString())==0){
                               ds.insert(user);
                                new AlertDialog.Builder(RegistrarActivity.this)
                                               .setTitle("Exito!!")
                                               .setMessage("Los datos del usuario se han registrado correctamente")
                                               .setCancelable(false)
                                               .setPositiveButton("OK",
                                                                    new DialogInterface.OnClickListener() {
                                                                        public void onClick(DialogInterface dialog, int id) {
                                                                            dialog.dismiss();
                                                                            startActivity(new Intent(RegistrarActivity.this, LoginActivity.class));
                                                                        }
                                                                  }).show();
                            }
                            else
                                Toast.makeText(RegistrarActivity.this,"Ese usario ya existe",Toast.LENGTH_LONG).show();
                        }else{
                            Toast.makeText(RegistrarActivity.this,"Ese Email lo tiene alguien mas",Toast.LENGTH_LONG).show();
                        }

                    }catch(SQLException e){
                        e.printStackTrace();
                    }

                }
            }
        });
        cv_borrar.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                et_nombre.setText("");
                et_email.setText("");
                et_password.setText("");
                et_conf_password.setText("");
                et_direccion.setText("");
            }
        });
        cv_volver.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrarActivity.this,LoginActivity.class));
                finish();
            }
        });
    }


    private int errCode(){
        int code = 0;//empty inputs
        if( et_nombre.getText().length()>0 ||
            et_email.getText().length()>0 ||
            et_password.getText().length()>0 ||
            et_conf_password.getText().length()>0 ||
            et_direccion.getText().length()>0){
            if(et_password.getText().toString().equals(et_conf_password.getText().toString())){
                code = 1;//correcto
            }else{
                code = 2;//password mal ingresado
            }
        }
        return code;
    }
}
