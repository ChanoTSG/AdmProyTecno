package com.example.chano.epdeportivo;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ItemOptionAdapter extends BaseAdapter {


    ArrayList<Option> option_list;
    Context context;
    int resource;
    public ItemOptionAdapter(Context context, ArrayList<Option> list) {
        this.option_list=list;
        this.context=context;
    }


    @Override
    public int getCount() {
        return option_list.size();
    }

    @Override
    public Object getItem(int position) {
        return option_list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        Option option = (Option)getItem(position);
        convertView = LayoutInflater.from(context).inflate( R.layout.adapter_option_item,null);

        ImageView iv_option = (ImageView) convertView.findViewById(R.id.iv_option);
        iv_option.setImageResource(option.getImage());
        iv_option.setBackgroundResource(option.getFondo());
        TextView tv_option = (TextView)convertView.findViewById(R.id.tv_option);
        tv_option.setTextColor(Color.WHITE);
        tv_option.setText(option.getOp_name());



        return convertView;
    }



}
