package com.example.chano.epdeportivo.model;

public class IndiceMasaCorporal {

    private int id_usuario;
    private String nombredeportista;
    private int id;
    private String fecha;
    private float imc;
    private String mensaje;

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombredeportista() {
        return nombredeportista;
    }

    public void setNombredeportista(String nombredepotista) {
        this.nombredeportista = nombredepotista;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public float getImc() {
        return imc;
    }

    public void setImc(float imc) {
        this.imc = imc;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public String toString(){
        return nombredeportista+" IMC calculado en "+fecha+" resultado :"+imc+" ("+mensaje+")";
    }

}
