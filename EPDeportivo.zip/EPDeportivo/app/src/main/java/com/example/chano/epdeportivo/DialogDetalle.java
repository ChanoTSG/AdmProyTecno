package com.example.chano.epdeportivo;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.v7.widget.CardView;

import com.example.chano.epdeportivo.model.PreparacionFisica;

public class DialogDetalle extends Dialog implements android.view.View.OnClickListener{

    private TextView tv_descripcion_dlg,tv_titulo_dlg;
    private ImageView iv_detalle;
    private CardView cv_cerrar;
    private Context a;
    private PreparacionFisica preparacionFisica;



    public DialogDetalle(Context context, PreparacionFisica preparacionFisica) {
        super(context);
        this.a=context;
        this.preparacionFisica=preparacionFisica;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_detalle);//es el nombre de mi DIALOG(archivo.xml)
        cv_cerrar = (CardView) findViewById(R.id.cv_cerrar);
        tv_descripcion_dlg=(TextView)findViewById(R.id.tv_descripcion_dlg);
        tv_titulo_dlg=(TextView)findViewById(R.id.tv_titulo_dlg);
        iv_detalle=(ImageView)findViewById(R.id.iv_detalle);
        cv_cerrar.setOnClickListener(this);

        tv_descripcion_dlg.setText(preparacionFisica.getDescripcion());
        tv_titulo_dlg.setText(preparacionFisica.getTitulo());
        iv_detalle.setImageResource(preparacionFisica.getImage());
    }


    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.cv_cerrar){
            dismiss();
        }
    }
}
