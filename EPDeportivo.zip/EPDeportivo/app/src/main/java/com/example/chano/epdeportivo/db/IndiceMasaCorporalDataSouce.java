package com.example.chano.epdeportivo.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.chano.epdeportivo.model.IndiceMasaCorporal;
import com.example.chano.epdeportivo.model.Resistencia;

import java.util.ArrayList;

public class IndiceMasaCorporalDataSouce {

    public String [] allColumns = {
            DataBaseHelper.ID_USR,
            DataBaseHelper.NOMDEPORTISTA,
            DataBaseHelper.ID_IMC,
            DataBaseHelper.FECHA_IMC,
            DataBaseHelper.IMC_CALCULADO,
            DataBaseHelper.MENSAJE
    };

    private SQLiteDatabase database;
    private DataBaseHelper dbHelper;

    public IndiceMasaCorporalDataSouce(Context c){
        dbHelper=new DataBaseHelper(c);
    }

    public void open() throws SQLException {
        database = dbHelper.getReadableDatabase();
    }

    public void close(){
        dbHelper.close();
    }

    private ContentValues resistenciaValues(IndiceMasaCorporal imc){
        ContentValues v = new ContentValues();
        if( imc.getId()>0 )
            v.put(DataBaseHelper.ID_IMC,imc.getId());
        v.put(DataBaseHelper.ID_USR,imc.getId_usuario());
        v.put(DataBaseHelper.FECHA_IMC,imc.getFecha());
        v.put(DataBaseHelper.IMC_CALCULADO,imc.getImc());
        v.put(DataBaseHelper.MENSAJE,imc.getMensaje());
        v.put(DataBaseHelper.NOMDEPORTISTA,imc.getNombredeportista());
        return v;
    }

    public long insert(IndiceMasaCorporal imc){
        ContentValues v = resistenciaValues(imc);
        long resp = database.insert(DataBaseHelper.TBL_IMC,null,v);
        return resp;
    }

    public ArrayList<IndiceMasaCorporal> getHistorialIMC(int id_usuario, String deportista){
        ArrayList<IndiceMasaCorporal> lista = new ArrayList<IndiceMasaCorporal>();
        Cursor c= null;
        try{

            String where = (deportista.equals(""))?DataBaseHelper.ID_USR+"="+id_usuario:"LOWER("+DataBaseHelper.NOMDEPORTISTA+") LIKE LOWER('%"+deportista+"%')";
            c=database.query(DataBaseHelper.TBL_IMC,allColumns,where,null,null,null,DataBaseHelper.ID_IMC+" DESC");
            IndiceMasaCorporal imc=null;
            if(c.getCount()>0){
                c.moveToFirst();
                while(!c.isAfterLast()){
                    imc = new IndiceMasaCorporal();
                    imc.setId(c.getInt(c.getColumnIndex(DataBaseHelper.ID_IMC)));
                    imc.setId_usuario(c.getInt(c.getColumnIndex(DataBaseHelper.ID_USR)));
                    imc.setImc(c.getFloat(c.getColumnIndex(DataBaseHelper.IMC_CALCULADO)));
                    imc.setFecha(c.getString(c.getColumnIndex(DataBaseHelper.FECHA_IMC)));
                    imc.setNombredeportista(c.getString(c.getColumnIndex(DataBaseHelper.NOMDEPORTISTA)));
                    imc.setMensaje(c.getString(c.getColumnIndex(DataBaseHelper.MENSAJE)));
                    lista.add(imc);
                    c.moveToNext();
                }
            }
        }finally{
            c.close();
        }
        return lista;
    }
}
