package com.example.chano.epdeportivo.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.chano.epdeportivo.model.User;

public class UserDataSource {

    private SQLiteDatabase database;
    private DataBaseHelper dbHelper;

    public UserDataSource(Context c){
        dbHelper = new DataBaseHelper(c);
    }

    public void open() throws SQLException {
        database = dbHelper.getReadableDatabase();
    }

    public void close(){
        dbHelper.close();
    }

    public String [] allColumns = {
            DataBaseHelper.ID_USER,
            DataBaseHelper.EMAIL,
            DataBaseHelper.FULLNAME,
            DataBaseHelper.DIRECCION,
            DataBaseHelper.PASSWORD,
            DataBaseHelper.KEEPSESSION
    };

    public User loginUser(String email){
        User user =  null;
        Cursor cursor = null;
        try {
            cursor = database.query(DataBaseHelper.TBL_USER,allColumns,DataBaseHelper.EMAIL+"='"+email+"'",null,null,null,null);
            if(cursor.getCount() > 0) {
                cursor.moveToFirst();
                user =new User();
                user.setUser_id(cursor.getInt(cursor.getColumnIndex(DataBaseHelper.ID_USER)));
                user.setFullname(cursor.getString(cursor.getColumnIndex(DataBaseHelper.FULLNAME)));
                user.setDireccion(cursor.getString(cursor.getColumnIndex(DataBaseHelper.DIRECCION)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(DataBaseHelper.PASSWORD)));
                user.setKeepSession(1);

            }
        }finally {
            cursor.close();
        }

        return user;
    }

    public int userExist(String name,String email,String password){
        int conteo =  0;
        Cursor cursor = null;
        try {
            String query = DataBaseHelper.FULLNAME+"='"+name.trim()+"' AND "+
                           DataBaseHelper.EMAIL+"='"+email.trim()+"' AND "+
                           DataBaseHelper.PASSWORD+"='"+password.trim()+"'";

            cursor = database.query(DataBaseHelper.TBL_USER,allColumns,query,null,null,null,null);
            conteo = cursor.getCount();

        }finally {
            cursor.close();
        }

        return conteo;
    }

    public boolean validateEmail(String email){
        boolean creado=false;
        Cursor cursor = null;
        try {
            String query = DataBaseHelper.EMAIL+"='"+email.trim()+"'";

            cursor = database.query(DataBaseHelper.TBL_USER,allColumns,query,null,null,null,null);
            creado = (cursor.getCount()>0);

        }finally {
            cursor.close();
        }

        return creado;
    }

    private ContentValues userValues(User u){
        ContentValues v = new ContentValues();
        if(u.getUser_id()>0)
            v.put(DataBaseHelper.ID_USER,u.getUser_id());
        if(!u.getFullname().toString().equals(""))
            v.put(DataBaseHelper.FULLNAME,u.getFullname());
        if(!u.getDireccion().toString().equals(""))
            v.put(DataBaseHelper.DIRECCION,u.getDireccion());
        if(!u.getPassword().toString().equals(""))
            v.put(DataBaseHelper.PASSWORD,u.getPassword());
        if(!u.getEmail().toString().equals(""))
            v.put(DataBaseHelper.EMAIL,u.getEmail());
        v.put(DataBaseHelper.KEEPSESSION,u.getKeepSession());

        return v;
    }

    public long insert(User u){
        ContentValues v = userValues(u);
        long resp = database.insert(DataBaseHelper.TBL_USER,null,v);
        return resp;
    }

    public long actualizar(User u){
        ContentValues v = userValues(u);
        long resp = database.update(DataBaseHelper.TBL_USER,v,DataBaseHelper.ID_USER+"="+u.getUser_id(),null);
        return resp;
    }

    public long disableUsers(int id){
        ContentValues v = new ContentValues();
        v.put(DataBaseHelper.KEEPSESSION,0);
        long resp = database.update(DataBaseHelper.TBL_USER, v, DataBaseHelper.ID_USER+"<>"+id,null);
        return resp;
    }

    public User loadUser(int session){
        User user =  null;
        Cursor cursor = null;
        try {
            cursor = database.query(DataBaseHelper.TBL_USER,allColumns,DataBaseHelper.KEEPSESSION+"="+session,null,null,null,null);
            if(cursor.getCount() > 0) {
                cursor.moveToFirst();
                user =new User();
                user.setUser_id(cursor.getInt(cursor.getColumnIndex(DataBaseHelper.ID_USER)));
                user.setFullname(cursor.getString(cursor.getColumnIndex(DataBaseHelper.FULLNAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(DataBaseHelper.EMAIL)));
                user.setDireccion(cursor.getString(cursor.getColumnIndex(DataBaseHelper.DIRECCION)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(DataBaseHelper.PASSWORD)));
                user.setKeepSession(cursor.getInt(cursor.getColumnIndex(DataBaseHelper.KEEPSESSION)));

            }
        }finally {
            cursor.close();
        }

        return user;
    }

}
