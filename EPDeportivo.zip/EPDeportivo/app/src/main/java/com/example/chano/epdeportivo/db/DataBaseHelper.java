package com.example.chano.epdeportivo.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "db_tuto";
    public static final int DATABASE_VERSION  =2;

    public static final String TBL_USER ="usuario";
    public static final String ID_USER = "id";
    public static final String EMAIL = "email";
    public static final String FULLNAME = "name";
    public static final String DIRECCION = "direccion";
    public static final String PASSWORD = "password";
    public static final String KEEPSESSION = "keep_session";

    private static final String CREATE_USER = "CREATE TABLE "+TBL_USER+"("+ID_USER+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                                                                        EMAIL+" VARCHAR(50), "+FULLNAME+" VARCHAR(50), "+
                                                                        DIRECCION+" TEXT, "+PASSWORD+" VARCHAR(50), "+
                                                                        KEEPSESSION+" INTEGER DEFAULT 1);";

    public static final String TBL_RESISTENCIA = "resistencia";
    public static final String ID_USER_RESISENCIA = "id_usuario";
    public static final String ID_RESISTENCIA = "id";
    public static final String FECHA = "fecha";
    public static final String TIEMPO = "tiempo";
    public static final String DISTANCIA ="distancia";
    public static final String NOMBREDEPORTISTA="nombre_completo";

    private static final String CREATE_RESISTENCIA = "CREATE TABLE "+TBL_RESISTENCIA+" ("+ID_RESISTENCIA+" INTEGER PRIMARY KEY AUTOINCREMENT,"+
                                                     ID_USER_RESISENCIA+" INTEGER, "+FECHA+" TEXT,"+TIEMPO+" TEXT,"+DISTANCIA+" NUMERIC,"+
                                                     NOMBREDEPORTISTA+" VARCHAR(50));";

    public static final String TBL_IMC ="imc";
    public static final String ID_USR="id_usuario";
    public static final String NOMDEPORTISTA ="nombredepotista";
    public static final String ID_IMC ="id";
    public static final String FECHA_IMC = "fecha";
    public static final String IMC_CALCULADO ="imc";
    public static final String MENSAJE= "mensaje";

    private static final String CREATE_IMC ="CREATE TABLE "+TBL_IMC+" ("+ID_IMC+" INTEGER PRIMARY KEY AUTOINCREMENT ,"+ID_USR+" INTEGER,"+
                                                                         NOMDEPORTISTA+" VARCHAR(50), "+FECHA_IMC+" VARCHAR(50), "+
                                                                         IMC_CALCULADO+" NUMERIC, "+MENSAJE+" TEXT);";

    public DataBaseHelper(Context c ){
        super(c,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER);
        db.execSQL(CREATE_RESISTENCIA);
        db.execSQL(CREATE_IMC);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TBL_USER);
        db.execSQL("DROP TABLE IF EXISTS "+TBL_RESISTENCIA);
        db.execSQL("DROP TABLE IF EXISTS "+TBL_IMC);
        onCreate(db);
    }
}