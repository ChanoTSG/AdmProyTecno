package com.example.chano.epdeportivo.model;

public class Resistencia {

    private int id;
    private int id_user;
    private String fecha;
    private String tiempo;
    private float distancia;
    private String nombreCompletoDeportista;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTiempo() {
        return tiempo;
    }

    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    public float getDistancia() {
        return distancia;
    }

    public void setDistancia(float distancia) {
        this.distancia = distancia;
    }

    public String getNombreCompletoDeportista() {
        return nombreCompletoDeportista;
    }

    public void setNombreCompletoDeportista(String nombreCompletoDeportista) {
        this.nombreCompletoDeportista = nombreCompletoDeportista;
    }

    @Override
    public String toString(){

        return nombreCompletoDeportista+" en :"+tiempo+" "+distancia+" km en "+fecha;
    }
}
