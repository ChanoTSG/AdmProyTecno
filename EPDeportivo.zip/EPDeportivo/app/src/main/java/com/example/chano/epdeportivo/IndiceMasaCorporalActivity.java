package com.example.chano.epdeportivo;

import android.database.SQLException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chano.epdeportivo.db.IndiceMasaCorporalDataSouce;
import com.example.chano.epdeportivo.db.UserDataSource;
import com.example.chano.epdeportivo.model.IndiceMasaCorporal;
import com.example.chano.epdeportivo.model.User;

import java.util.Calendar;

public class IndiceMasaCorporalActivity extends AppCompatActivity {

    CardView cv_borrar, cv_calcular;
    TextView tv_msg2, tv_msg1,tv_fecha;
    EditText et_nom_completo, et_peso,et_altura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_indice_masa_corporal);

        tv_msg1= (TextView)findViewById(R.id.tv_msg1);
        tv_msg2= (TextView)findViewById(R.id.tv_msg2);
        tv_fecha= (TextView)findViewById(R.id.tv_fecha);

        et_nom_completo = (EditText)findViewById(R.id.et_nom_completo);
        et_altura = (EditText)findViewById(R.id.et_altura);
        et_peso = (EditText)findViewById(R.id.et_peso);

        cv_calcular=(CardView)findViewById(R.id.cv_calcular);
        cv_borrar=(CardView)findViewById(R.id.cv_borrar);

        Calendar calendar = Calendar.getInstance();
        String mes = ((Calendar.MONTH+1)<10)?String.valueOf("0"+(Calendar.MONTH+1)):String.valueOf(Calendar.MONTH + 1);
        String fecha = calendar.get(Calendar.YEAR)+"-"+mes+"-"+calendar.get(Calendar.DAY_OF_MONTH);
        tv_fecha.setText(fecha);


        cv_borrar.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                tv_msg1.setText("");
                tv_msg2.setText("");
                et_nom_completo.setText("");
                et_altura.setText("");
                et_peso.setText("");
            }
        });

        cv_calcular.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if(validate()){
                    float imc = getImc();
                    tv_msg1.setText("El IMC de "+et_nom_completo.getText().toString()+" es "+imc);

                    if(imc<18.5){
                        tv_msg2.setText("está dentro de los valores correspondientes a 'bajo peso'");
                    }else if(imc>=18.5 && imc<24.9){
                        tv_msg2.setText("está dentro de los valores 'normales' o de peso saludable.");
                    }else if(imc>=24.9 && imc<29.9){
                        tv_msg2.setText("está dentro de los valores correspondientes a 'sobrepeso'.");
                    }else if(imc>=29.9){
                        tv_msg2.setText("está dentro de los valores de 'obesidad'.");
                    }
                    IndiceMasaCorporal imcOBJ =new IndiceMasaCorporal();
                    imcOBJ.setImc(imc);
                    imcOBJ.setId_usuario(loadUser().getUser_id());
                    imcOBJ.setNombredeportista(et_nom_completo.getText().toString());
                    imcOBJ.setFecha(tv_fecha.getText().toString());
                    imcOBJ.setMensaje(tv_msg2.getText().toString());
                    saveIMC(imcOBJ);
                }else{
                    Toast.makeText(IndiceMasaCorporalActivity.this,"Llene todos los campos",Toast.LENGTH_LONG).show();
                }
            }
        });

    }


    private User loadUser(){
        User u=null;
        UserDataSource ds=new UserDataSource(IndiceMasaCorporalActivity.this);
        try{
            ds.open();
            u=ds.loadUser(1);

        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(IndiceMasaCorporalActivity.this,"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return u;
    }


    private void saveIMC(IndiceMasaCorporal obj){
        IndiceMasaCorporalDataSouce ds = new IndiceMasaCorporalDataSouce(IndiceMasaCorporalActivity.this);
        try{
            ds.open();
            ds.insert(obj);
        }catch(SQLException e){
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }


    private boolean validate(){
        return (et_peso.getText().length()>0&&et_altura.getText().length()>0&&et_nom_completo.getText().length()>0);
    }

    private float getImc(){
        float numerador =  Float.parseFloat(et_peso.getText().toString());
        float denominador = Float.parseFloat(et_altura.getText().toString())*Float.parseFloat(et_altura.getText().toString());
        return numerador/denominador;
    }


}
